package com.example.sendmailwithattachment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SendmailwithattachmentApplication {

    public static void main(String[] args) {
        SpringApplication.run(SendmailwithattachmentApplication.class,args);
    }
}